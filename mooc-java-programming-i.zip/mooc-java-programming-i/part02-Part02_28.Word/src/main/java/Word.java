
public class Word {

    public static void main(String[] args) {
        word();
    }
    
    public static String word(){
        return "word of my choice";
    }
}
