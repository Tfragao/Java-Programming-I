
public class NumberUno {

    public static void main(String[] args) {
        numberUno();

    }
    
    public static int numberUno(){
        return 1;
    }
}
